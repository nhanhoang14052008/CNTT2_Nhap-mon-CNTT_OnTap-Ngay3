﻿# Website Trung tâm Tiếng Anh TTA

## Giới thiệu

Website TTA giúp học viên tìm hiểu khóa học và gửi đăng ký trực tuyến.

Dự án hỗ trợ **quản lý thông tin khóa học** và _tra cứu học phí._

## Cấu trúc thư mục

| Thư mục | Nội dung |

|---|---|

| `data` | Bảng học viên và học phí |

| `docs` | Tài liệu của dự án |

| `logs`| Nhật ký hoạt động |

| `media` | Hình ảnh và logo |

| `archive` | Tài nguyên lưu trữ |

## Quy trình đăng ký học

1. Chọn khóa học muốn đăng ký.

2. Điền thông tin và gửi biểu mẫu đăng ký.

3. Kiểm tra học phí và hoàn tất thanh toán.
# Dự án quản lý trung tâm tiếng anh TTA

## Giới thiệu dự án
Dự án được xây dựng nhằm mục đích tối ưu hóa quy trình **quản lý học viên** và *tính toán học phí hàng tháng* cho Trung tâm tiếng Anh TTA.

## Cấu trúc thư mục dự án
| Thư mục / File | Mô tả nội dung chi tiết |
| :--- | :--- |
| `archive/` | Lưu trữ dữ liệu và hồ sơ các khóa học cũ |
| `data/` | Chứa các file bảng tính Excel (danh sách học viên, học phí) |
| `docs/` | Tài liệu kỹ thuật và hướng dẫn sử dụng hệ thống |

## Quy trình đăng ký học tại TTA
1. Học viên tham khảo danh mục khóa học và lựa chọn mã khóa phù hợp.
2. Điền thông tin cá nhân cùng số tháng đăng ký vào hệ thống quản lý.
3. Kế toán xác nhận học phí và hoàn tất thủ tục ghi danh cho học viên.

## Lệnh PowerShell liệt kê nội dung
```powershell
Get-ChildItem -Recurse
